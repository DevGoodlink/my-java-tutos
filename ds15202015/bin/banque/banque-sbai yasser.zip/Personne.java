package banque;

public class Personne {
	int idBancaire;
	String NomComplet;

	public Personne(int idBancaire, String nomComplet) {
		this.idBancaire = idBancaire;
		NomComplet = nomComplet;
	}

	public int getIdBancaire() {
		return idBancaire;
	}

	public void setIdBancaire(int idBancaire) {
		this.idBancaire = idBancaire;
	}

	public String getNomComplet() {
		return NomComplet;
	}

	public void setNomComplet(String nomComplet) {
		NomComplet = nomComplet;
	}


	public String toString() {
		return "Personne [idBancaire = " + idBancaire + ", NomComplet = " + NomComplet + "]";
	}

}
