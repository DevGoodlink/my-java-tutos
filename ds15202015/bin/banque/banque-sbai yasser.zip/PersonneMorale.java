package banque;

public class PersonneMorale extends Personne {
	String activite;

	public PersonneMorale(int idBancaire, String nomComplet, String activite) {
		super(idBancaire, nomComplet);
		this.activite = activite;
	}

	public String getActivite() {
		return activite;
	}

	public void setActivite(String activite) {
		this.activite = activite;
	}

	public String toString() {
		return "PersonneMorale [ NomComplet=" + super.getNomComplet() +
				"\n activite =" + activite +",\n idBancaire=" + super.getIdBancaire() +"]";
	}

}
