package banque;

public class CompteBancaire {
	private int numcompte;
	private String addr;

	public CompteBancaire(int numcompte, String addr) {
		this.numcompte = numcompte;
		this.addr = addr;
	}

	public int getNumcompte() {
		return numcompte;
	}

	public void setNumcompte(int numcompte) {
		this.numcompte = numcompte;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

}
